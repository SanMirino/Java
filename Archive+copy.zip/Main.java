import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
public class Main {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Hello world!");

        MyThread t1 = new MyThread();
        t1.setName("Thread 1");
        MyThread t2 = new MyThread();
        t2.setName("Thread 2");

        boolean end = false;
        while (!end) {
            t1.run();
            t2.run();
        }
    }
}