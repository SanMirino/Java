public class MyThread extends Thread {
    @Override
    public void run() {
        super.run();

        System.out.println(this.getName());
        try {
            sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}