import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    static boolean compareFiles(String pathFile1, String pathFile2) throws IOException {
        byte[] arrayFile1 = Files.readAllBytes(Paths.get(pathFile1));
        byte[] arrayFile2 = Files.readAllBytes(Paths.get(pathFile2));

        return Arrays.equals(arrayFile1, arrayFile2);
    }

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите путь до 1-го файла: ");
        String f1 = scanner.next();

        System.out.println("Введите путь до 2-го файла: ");
        String f2 = scanner.next();

        System.out.println("Файлы равны: " + compareFiles(f1, f2));
    }
}
