public class Main {
    public static void main(String[] args) throws InterruptedException {
        Buffer buffer = new Buffer(5);

        Producer producer = new Producer(buffer);
        Consumer consumer = new Consumer(buffer);

        producer.start();
        consumer.start();

        Thread.sleep(10000);

        producer.interrupt();
        consumer.interrupt();

        producer.join();
        consumer.join();

        System.out.println("Конец");
    }
}