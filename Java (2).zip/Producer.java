public class Producer extends Thread {
    final Buffer buffer;

    public Producer(Buffer buffer) {
        this.buffer = buffer;
    }

    private boolean threadFinish = false;

    private void finish() {
        threadFinish = true;
    }

    @Override
    public void run() {
        while (!threadFinish) {
            synchronized (buffer) {
                if (buffer.data.size() == buffer.capacity) {
                    try {
                        buffer.wait();
                    } catch (InterruptedException e) {
                        finish();
                    }
                } else {
                    int number = (int) (Math.random() * 11);
                    buffer.data.add(number);
                    buffer.notifyAll();
                    System.out.println("Producer добавил число " + number);
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        finish();
                    }
                }
            }
        }
    }
}