package com.example.demo;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

public class AddRequestController {
    @FXML
    private TextField workTextField;
    @FXML
    private TextField userIdTextField;

    @FXML
    private Button addButton;

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void addRequest() {
        String work = workTextField.getText();
        String userIdText = userIdTextField.getText();

        if (work.isEmpty() || userIdText.isEmpty()) {
            showErrorMessage("Please enter all fields");
            return;
        }

        int userId;
        try {
            userId = Integer.parseInt(userIdText);
        } catch (NumberFormatException e) {
            showErrorMessage("Invalid User ID");
            return;
        }

        // Perform server request
        String requestUrl = "http://localhost:8000/add-request?";
        //String requestBody = "work=" + work + "&user_id=" + userId;

        try {
            // Создание URL с параметрами запроса
            String encodedWork = URLEncoder.encode(work, "UTF-8");
            String queryString = "work=" + encodedWork + "&userId=" + userId;
            String fullUrl = requestUrl + "?" + queryString;
            URL url = new URL(fullUrl);

            // Открытие соединения HTTP
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            connection.getInputStream();



            // Закрытие соединения
            connection.disconnect();

        } catch (IOException e) {
            //e.printStackTrace();
        }
        showInfoMessage("Request added successfully");
        clearFields();
    }


    private void showInfoMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        workTextField.clear();
        userIdTextField.clear();
    }
}