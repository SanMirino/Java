package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.*;

public class MainController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    protected void onGetUserDataButtonClick() {
        // Получение данных о пользователях из базы данных
        String userData = fetchDataFromDatabase();

        // Вывод информации о пользователях в метку
        welcomeText.setText(userData);

    }
    String dbUrl = "jdbc:sqlite:identifier.sqlite";
    private String fetchDataFromDatabase() {


        StringBuilder userData = new StringBuilder();

        try {
            Connection connection = DriverManager.getConnection(dbUrl);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Users");

            while (resultSet.next()) {
                int id = resultSet.getInt("Id");
                String name = resultSet.getString("Name");
                int age = resultSet.getInt("Age");

                // Формирование строки с информацией о пользователе
                String userEntry = "ID: " + id + ", Name: " + name + ", Age: " + age;
                userData.append(userEntry).append("\n");
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return userData.toString();
    }

    public void AddUserButtonClick(ActionEvent actionEvent) {
        try (Connection connection = DriverManager.getConnection(dbUrl);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO Users (Name, Age) VALUES (?, ?)")) {

            statement.setString(1, "test");
            statement.setInt(2, Integer.parseInt("15"));

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Новый пользователь добавлен в базу данных.");
            } else {
                System.out.println("Не удалось добавить нового пользователя.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addUser() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("addUser.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.initModality(Modality.WINDOW_MODAL);
            //newStage.initOwner(stage); // Здесь stage - это ссылка на Stage вашего основного окна
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private TextField nameField;

    @FXML
    private TextField surnameField;

    @FXML
    private TextField ageField;

    public void toBase() {

        String name = nameField.getText();
        String surname = surnameField.getText();
        String userAge = ageField.getText();

        if (name.isEmpty() || surname.isEmpty() || userAge.isEmpty()) {
            showErrorMessage("Please enter all fields");
            return;
        }

        int userAgeInt;
        try {
            userAgeInt = Integer.parseInt(userAge);
        } catch (NumberFormatException e) {
            showErrorMessage("Invalid User Age");
            return;
        }

        // Perform server request
        String requestUrl = "http://localhost:8000/add-user";
        //String requestBody = "work=" + work + "&user_id=" + userId;

        try {
            // Создание URL с параметрами запроса
            //String encodedWork = URLEncoder.encode(work, "UTF-8");
            String queryString = "Name=" + name + "&surname=" + surname + "&age=" + userAgeInt;
            System.out.println(queryString);
            String fullUrl = requestUrl + "?" + queryString;
            System.out.println(fullUrl);
            URL url = new URL(fullUrl);

            // Открытие соединения HTTP
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            connection.getInputStream();



            // Закрытие соединения
            connection.disconnect();

        } catch (IOException e) {
            //e.printStackTrace();
        }
        showInfoMessage("Request added successfully");
        clearFields();

        /*
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());

        // Подключение к базе данных SQLite

        try (Connection connection = DriverManager.getConnection(dbUrl)) {
            // Подготовка SQL-запроса для вставки данных пользователя
            String sql = "INSERT INTO users (name, age) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setInt(2, age);

            // Выполнение SQL-запроса для добавления пользователя
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Новый пользователь добавлен в базу данных");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Очистка полей ввода
        nameField.clear();
        ageField.clear();

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("UserInfo.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.initModality(Modality.WINDOW_MODAL);
            //newStage.initOwner(stage); // Здесь stage - это ссылка на Stage вашего основного окна
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

         */
    }

    private void showInfoMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        nameField.clear();
        surnameField.clear();
        ageField.clear();
    }

    public void openTableWindow(ActionEvent actionEvent) {
        /*
        try (Connection connection = DriverManager.getConnection(dbUrl);
             Statement statement = connection.createStatement()) {

            String sql = "SELECT * FROM requests";
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String work = resultSet.getString("work");
                int userId = resultSet.getInt("user_id");
                String status = resultSet.getString("status");

                System.out.println("ID: " + id + ", Work: " + work + ", User ID: " + userId + ", Status: " + status);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
*/

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("requestsTable.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.initModality(Modality.WINDOW_MODAL);
            //newStage.initOwner(stage); // Здесь stage - это ссылка на Stage вашего основного окна
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void openUsersTable(ActionEvent actionEvent) {
        /*
        try (Connection connection = DriverManager.getConnection(dbUrl);
             Statement statement = connection.createStatement()) {

            String sql = "SELECT * FROM Users";
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("Name");
                String surname = resultSet.getString("surname");
                int age = resultSet.getInt("age");


                System.out.println("ID: " + id + ", name: " + name + ", surname: " + surname + ", age: " + age);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        */

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("usersTable.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.initModality(Modality.WINDOW_MODAL);
            //newStage.initOwner(stage); // Здесь stage - это ссылка на Stage вашего основного окна
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addRequest() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("addRequest.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.initModality(Modality.WINDOW_MODAL);
            //newStage.initOwner(stage); // Здесь stage - это ссылка на Stage вашего основного окна
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void about() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("About.fxml"));
            Parent root = loader.load();

            Stage newStage = new Stage();
            newStage.initModality(Modality.WINDOW_MODAL);
            //newStage.initOwner(stage); // Здесь stage - это ссылка на Stage вашего основного окна
            newStage.setScene(new Scene(root));
            newStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}