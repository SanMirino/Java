package com.example.demo;

public class Request {
    private int id;
    private String work;
    private int userId;

    private String status;
    public Request(int id, String work, int userId, String status) {
        this.id = id;
        this.work = work;
        this.userId = userId;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getWork() {
        return work;
    }

    public int getUserId() {
        return userId;
    }

    public String getStatus() {
        return status;
    }
}
