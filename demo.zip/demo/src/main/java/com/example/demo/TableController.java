package com.example.demo;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class TableController {
    @FXML
    private TableView<Request> requestsTable;

    @FXML
    private TableColumn<Request, Integer> idColumn;

    @FXML
    private TableColumn<Request, String> workColumn;

    @FXML
    private TableColumn<Request, Integer> userIdColumn;

    @FXML
    private TableColumn<Request, Boolean> statusColumn;

    public void initialize() {
        String baseUrl = "http://localhost:8000/requests";

        try {
            // Создаем объект URL на основе URL-адреса запроса
            URL url = new URL(baseUrl);

            // Открываем соединение HTTP
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Устанавливаем метод запроса на GET
            connection.setRequestMethod("GET");

            // Получаем ответный код
            int responseCode = connection.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // Читаем ответ сервера
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Парсим JSON-ответ
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(response.toString());

            // Создаем список для хранения объектов Request
            List<Request> requestList = new ArrayList<>();

            // Итерируем по JSON-массиву и создаем объекты Request
            for (Object obj : jsonArray) {
                JSONObject jsonObj = (JSONObject) obj;
                int id = Integer.parseInt(jsonObj.get("id").toString());
                String work = jsonObj.get("work").toString();
                int userId = Integer.parseInt(jsonObj.get("userId").toString());
                String status = jsonObj.get("status") != null ? jsonObj.get("status").toString() : "в работе";

                Request request = new Request(id, work, userId, status);
                requestList.add(request);
            }

            // Добавляем объекты Request в таблицу
            requestsTable.getItems().addAll(requestList);

            // Закрываем соединение
            connection.disconnect();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        workColumn.setCellValueFactory(new PropertyValueFactory<>("work"));
        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
    }
}
