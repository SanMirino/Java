package com.example.demo;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UsersTableController {
    @FXML
    private TableView<UserRequest> requestsTable;

    @FXML
    private TableColumn<UserRequest, Integer> idColumn;

    @FXML
    private TableColumn<UserRequest, String> workColumn;

    @FXML
    private TableColumn<UserRequest, Integer> userIdColumn;

    @FXML
    private TableColumn<UserRequest, Boolean> statusColumn;

    public void initialize() {
        String baseUrl = "http://localhost:8000/users";

        try {
            // Создаем объект URL на основе URL-адреса запроса
            URL url = new URL(baseUrl);

            // Открываем соединение HTTP
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Устанавливаем метод запроса на GET
            connection.setRequestMethod("GET");

            // Получаем ответный код
            int responseCode = connection.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // Читаем ответ сервера
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Парсим JSON-ответ
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(response.toString());

            // Создаем список для хранения объектов Request
            List<Request> requestList = new ArrayList<>();

            // Итерируем по JSON-массиву и создаем объекты Request
            for (Object obj : jsonArray) {
                JSONObject jsonObj = (JSONObject) obj;
                int id = Integer.parseInt(jsonObj.get("id").toString());
                String name = jsonObj.get("name").toString() != null ? jsonObj.get("name").toString() : "";;
                String surname = jsonObj.get("surname").toString() != null ? jsonObj.get("surname").toString() : "";;
                int age = jsonObj.get("Age") != null ? Integer.parseInt(jsonObj.get("Age").toString()) : 0;

                UserRequest request = new UserRequest(id, name, surname, age);
                requestsTable.getItems().add(request);
            }

            // Добавляем объекты Request в таблицу
            //requestsTable.getItems().addAll(requestList);

            // Закрываем соединение
            connection.disconnect();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        workColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("Surname"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("Age"));
        /*
        String url = "jdbc:sqlite:identifier.sqlite";

        try (Connection connection = DriverManager.getConnection(url);
             Statement statement = connection.createStatement()) {

            String sql = "SELECT * FROM Users";
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("Name");
                String surname = resultSet.getString("surname");
                int age = resultSet.getInt("age");

                UserRequest request = new UserRequest(id, name, surname, age);
                requestsTable.getItems().add(request);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        workColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("Surname"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("Age"));
        */
    }
}
