package org.example;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class LocalServer {
    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/add-request", new AddRequestHandler());
        server.createContext("/add-user", new AddUserHandler());
        server.createContext("/requests", new RequestHandler());
        server.createContext("/users", new UsersHandler());
        server.setExecutor(null); // Используем дефолтный исполнитель

        // Запускаем сервер
        server.start();

        System.out.println("Сервер запущен на порту 8000");
    }

    static class AddRequestHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                // Получаем параметры запроса
                String workr = exchange.getRequestURI().getQuery().split("&")[0].split("=")[1];
                int userIdr = Integer.parseInt(exchange.getRequestURI().getQuery().split("&")[1].split("=")[1]);
                System.out.println(workr);
                System.out.println(userIdr);
                workr = new String("'" + workr + "'");
                String url = "jdbc:sqlite:C:/Users/vital/IdeaProjects/demo/identifier.sqlite";
                String insertQuery = String.format("INSERT INTO requests (work, user_id) VALUES (%s, %d)", workr, userIdr);


                try (Connection connection = DriverManager.getConnection(url);
                     Statement statement = connection.createStatement()) {

                    int rowsInserted = statement.executeUpdate(insertQuery);
                    if (rowsInserted > 0) {
                        System.out.println("Data inserted successfully");
                    } else {
                        System.out.println("Failed to insert data");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                exchange.getResponseBody().close();
            } else {
                // Отправляем ошибку "Method Not Allowed" для других методов запросов
                String response = "Method Not Allowed";
                exchange.sendResponseHeaders(405, response.length());
                exchange.getResponseBody().write(response.getBytes());
                exchange.getResponseBody().close();
            }
        }
    }

    static class AddUserHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                String query = exchange.getRequestURI().getQuery();

                String name = null;
                String surname = null;
                int age = 0;

                if (query != null) {
                    String[] queryParams = query.split("&");
                    for (String param : queryParams) {
                        String[] keyValue = param.split("=");
                        if (keyValue.length == 2) {
                            String key = keyValue[0];
                            String value = keyValue[1];

                            if (key.equals("Name")) {
                                name = value;
                            } else if (key.equals("surname")) {
                                surname = value;
                            } else if (key.equals("age")) {
                                try {
                                    age = Integer.parseInt(value);
                                } catch (NumberFormatException e) {
                                    // Обработка ошибки некорректного значения age
                                }
                            }
                        }
                    }
                }

                System.out.println("Name: " + name);
                System.out.println("Surname: " + surname);
                System.out.println("Age: " + age);

// Формирование SQL-запроса
                String url = "jdbc:sqlite:C:/Users/vital/IdeaProjects/demo/identifier.sqlite";
                String insertQuery = String.format("INSERT INTO Users (Name, surname, age) VALUES ('%s', '%s', %d)",
                        name, surname, age);


                try (Connection connection = DriverManager.getConnection(url);
                     Statement statement = connection.createStatement()) {

                    int rowsInserted = statement.executeUpdate(insertQuery);
                    if (rowsInserted > 0) {
                        System.out.println("Data inserted successfully");
                    } else {
                        System.out.println("Failed to insert data");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                exchange.getResponseBody().close();
            } else {
                // Отправляем ошибку "Method Not Allowed" для других методов запросов
                String response = "Method Not Allowed";
                exchange.sendResponseHeaders(405, response.length());
                exchange.getResponseBody().write(response.getBytes());
                exchange.getResponseBody().close();
            }
        }
    }

    static class RequestHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                handleGetRequest(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
            }
        }

        private void handleGetRequest(HttpExchange exchange) throws IOException {
            String response = getRequestsFromDatabase();
            exchange.sendResponseHeaders(200, response.getBytes().length);
            OutputStream outputStream = exchange.getResponseBody();
            outputStream.write(response.getBytes());
            outputStream.close();
        }

        private String getRequestsFromDatabase() {
            String url = "jdbc:sqlite:C:/Users/vital/IdeaProjects/demo/identifier.sqlite";
            JSONArray jsonArray = new JSONArray();

            try (Connection connection = DriverManager.getConnection(url);
                 Statement statement = connection.createStatement()) {

                String selectQuery = "SELECT * FROM requests";
                ResultSet resultSet = statement.executeQuery(selectQuery);

                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String work = resultSet.getString("work");
                    int userId = resultSet.getInt("user_id");
                    String status = resultSet.getString("status");

                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("id", id);
                    jsonObject.put("work", work);
                    jsonObject.put("userId", userId);
                    jsonObject.put("status", status);

                    jsonArray.add(jsonObject);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            return jsonArray.toJSONString();
        }
    }

    static class UsersHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                handleGetRequest(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
            }
        }

        private void handleGetRequest(HttpExchange exchange) throws IOException {
            String response = getRequestsFromDatabase();
            exchange.sendResponseHeaders(200, response.getBytes().length);
            OutputStream outputStream = exchange.getResponseBody();
            outputStream.write(response.getBytes());
            outputStream.close();
        }

        private String getRequestsFromDatabase() {
            String url = "jdbc:sqlite:C:/Users/vital/IdeaProjects/demo/identifier.sqlite";
            JSONArray jsonArray = new JSONArray();

            try (Connection connection = DriverManager.getConnection(url);
                 Statement statement = connection.createStatement()) {

                String selectQuery = "SELECT * FROM Users";
                ResultSet resultSet = statement.executeQuery(selectQuery);

                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String name = resultSet.getString("Name");
                    String surname = resultSet.getString("surname");
                    String Age = resultSet.getString("Age");



                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("id", id);
                    jsonObject.put("name", name);
                    jsonObject.put("surname", surname);
                    jsonObject.put("Age", Age);

                    jsonArray.add(jsonObject);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            return jsonArray.toJSONString();
        }
    }
}