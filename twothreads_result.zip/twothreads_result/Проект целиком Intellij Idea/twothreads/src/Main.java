import java.util.concurrent.TimeUnit;

public class Main {
    private static int whoIsNext = 1;   //Чья очередь выводить свое имя (вначале 1 - очередь первого потока)
    public static void main(String[] args) {

        /*Создадим задачу (task1) для вывода имени первого потока. Для этого реализуем интерфейс Runnable.
        * У этого интерфейса есть только один метод void run(). */
        Runnable task1 = () -> {
            /*Будем выводить имя 10 раз. Чтобы поток не был "вечным" и программа когда-то закончилась.*/
            for(int i=0; i<10; ){
                /* Если очередь первого потока выводить имя, то выводим его и следующего для вывода имени
                 * назначаем второй поток.*/
                if(whoIsNext==1){
                    System.out.println("I am a FIRST thread.");
                    whoIsNext=2;
                    i++;
                }
                /*Делаем паузу 1 секунду*/
                try {
                    TimeUnit.SECONDS.sleep(1L);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        };

        /*Создадим задачу (task2) для вывода имени второго потока. Для этого так же реализуем интерфейс Runnable.*/
        Runnable task2 = () -> {
            /*Выводим имя 10 раз*/
            for(int i=0; i<10; ){
                /*Если только очередь второго потока выводить свое имя.*/
                if(whoIsNext==2){
                    System.out.println("I am a SECOND thread.");
                    whoIsNext=1;    //Вывели имя, передали очередь первому потоку.
                    i++;
                }
                /*Пауза 1 сек*/
                try {
                    TimeUnit.SECONDS.sleep(1L);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        };


        Thread thread1 = new Thread(task1); //создаем поток, который выполнит задачу 1
        Thread thread2 = new Thread(task2); //создаем поток, который выполнит задачу 2
        thread1.start();    //запуск потока 1
        thread2.start();    //запуск потока 2
        /*Когда каждый из них выведет свое имя 10 раз, поток выйдет из задачи и завершится*/
    }
}